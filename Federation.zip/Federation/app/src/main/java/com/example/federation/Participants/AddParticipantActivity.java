package com.example.federation.Participants;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.federation.Events.EventInformationActivity;
import com.example.federation.R;
import com.example.federation.SQLite.DatabaseLRHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AddParticipantActivity extends AppCompatActivity {
    DatabaseLRHandler db;
    EditText name,email,phone,dateOfBirth,postalAddress,nameOfOrganization;
    Button submit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_participant);
        db=new DatabaseLRHandler(this);
        name=(EditText)findViewById(R.id.participantName);
        email=(EditText)findViewById(R.id.participantEmail);
        phone=(EditText)findViewById(R.id.phoneNumber);
        submit=(Button)findViewById(R.id.registerButton);
        dateOfBirth=(EditText)findViewById(R.id.dateOfBirth);
        postalAddress=(EditText)findViewById(R.id.address);
        nameOfOrganization=(EditText)findViewById(R.id.nameOfOrganization);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(name.getText().toString().trim().equals("")||email.getText().toString().trim().equals("")){
                    Toast.makeText(getApplicationContext(),"Name and Email required",Toast.LENGTH_SHORT).show();
                }
                else{
                    JSONArray jsonArray=new JSONArray();
                    JSONObject jsonObject=new JSONObject();
                    try {
                        jsonObject.put("Date of Birth",dateOfBirth.getText().toString().trim());
                        jsonObject.put("Postal Address",postalAddress.getText().toString().trim());
                        jsonObject.put("Name of Organization",nameOfOrganization.getText().toString().trim());
                        jsonArray.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    db.addParticipant(name.getText().toString().trim(),email.getText().toString().trim(),phone.getText().toString().trim(),getIntent().getIntExtra("eventId",0),jsonArray.toString());
                    Intent in=new Intent(getApplicationContext(), EventInformationActivity.class);
                    in.putExtra("eventCode",getIntent().getStringExtra("eventCode"));
                    in.putExtra("eventName",getIntent().getStringExtra("eventName"));
                    in.putExtra("eventId",getIntent().getIntExtra("eventId",0));
                    startActivity(in);
                }
            }
        });
    }
}
