package com.example.federation.Events;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.federation.R;
import com.example.federation.SQLite.DatabaseLRHandler;

/**
 * Created by Aakash on 15-Apr-17.
 */

public class CreateEvent extends AppCompatActivity {
    EditText eventCode,eventName,eventVenue,eventStartingDate,eventEndingDate;
    Button submit;
    DatabaseLRHandler db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_event);
        eventCode=(EditText)findViewById(R.id.event_code);
        eventName=(EditText)findViewById(R.id.event_name);
        eventVenue=(EditText)findViewById(R.id.event_venue);
        eventStartingDate=(EditText)findViewById(R.id.eventStartingDate);
        eventEndingDate=(EditText)findViewById(R.id.eventEndingDate);
        submit=(Button)findViewById(R.id.button);
        db=new DatabaseLRHandler(this);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(eventName.getText().toString().trim().equals("")||eventCode.getText().toString().trim().equals("")||
                        eventVenue.getText().toString().trim().equals("")||eventStartingDate.getText().toString().trim().equals("")
                        ||eventEndingDate.getText().toString().trim().equals(""))
                {
                    Toast.makeText(getApplicationContext(),"Fill all the deteils properly",Toast.LENGTH_SHORT).show();
                }
                else{
                    db.addEvent(eventCode.getText().toString().trim(),eventName.getText().toString().trim(),eventVenue.getText().toString().trim(),
                            eventStartingDate.getText().toString().trim(),eventEndingDate.getText().toString().trim());
                    Intent in=new Intent(getApplicationContext(),EventActivity.class);
                    startActivity(in);
                    finish();
                }
            }
        });
    }
}
